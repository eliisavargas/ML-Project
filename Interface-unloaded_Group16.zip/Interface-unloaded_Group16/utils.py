
zip_codes_by_state = {
    "AL": {"start": 35201, "end": 36925},
    "AK": {"start": 99501, "end": 99950},
    "AZ": {"start": 85001, "end": 86556},
    "AR": {"start": 72201, "end": 72959},
    "CA": {"start": 90001, "end": 96162},
    "CO": {"start": 80201, "end": 81658},
    "CT": {"start": 6101, "end": 6909},
    "DE": {"start": 19901, "end": 19980},
    "FL": {"start": 33101, "end": 34997},
    "GA": {"start": 30301, "end": 31999},
    "HI": {"start": 96801, "end": 96898},
    "ID": {"start": 83701, "end": 83877},
    "IL": {"start": 60001, "end": 62999},
    "IN": {"start": 46201, "end": 47997},
    "IA": {"start": 50301, "end": 52999},
    "KS": {"start": 66101, "end": 67954},
    "KY": {"start": 40201, "end": 42788},
    "LA": {"start": 70112, "end": 71497},
    "ME": {"start": 4101, "end": 4999},
    "MD": {"start": 21201, "end": 21930},
    "MA": {"start": 2101, "end": 2199},
    "MI": {"start": 48201, "end": 49971},
    "MN": {"start": 55101, "end": 56763},
    "MS": {"start": 39201, "end": 39776},
    "MO": {"start": 63101, "end": 65899},
    "MT": {"start": 59001, "end": 59937},
    "NE": {"start": 68101, "end": 69367},
    "NV": {"start": 89501, "end": 89775},
    "NH": {"start": 3311, "end": 3874},
    "NJ": {"start": 7110, "end": 8999},
    "NM": {"start": 87501, "end": 88439},
    "NY": {"start": 10001, "end": 14925},
    "NC": {"start": 27501, "end": 28909},
    "ND": {"start": 58102, "end": 58856},
    "OH": {"start": 44101, "end": 44999},
    "OK": {"start": 73101, "end": 74966},
    "OR": {"start": 97201, "end": 97920},
    "PA": {"start": 19101, "end": 19640},
    "RI": {"start": 2901, "end": 2999},
    "SC": {"start": 29201, "end": 29945},
    "SD": {"start": 57101, "end": 57799},
    "TN": {"start": 37201, "end": 38589},
    "TX": {"start": 75001, "end": 79999},
    "UT": {"start": 84101, "end": 84791},
    "VT": {"start": 5651, "end": 5997},
    "VA": {"start": 23218, "end": 24658},
    "WA": {"start": 98001, "end": 99403},
    "WV": {"start": 25301, "end": 26719},
    "WI": {"start": 53201, "end": 54990},
    "WY": {"start": 82001, "end": 83128}
}

def get_state_for_zip(zip_code):
    try:
        zip_code = int(zip_code)  
    except ValueError:  
        return 'Unknown'
    
    for state, range_ in zip_codes_by_state.items():
        if range_['start'] <= zip_code <= range_['end']:
            return state
    return 'Unknown'
    
zips = [
    (10001, 10282, 'NYC'), (11722, 11788, 'Hauppage'), 
    (12201, 12288, 'Albany'), (13120, 13290, 'Syracuse'), 
    (13901, 13905, 'Binghamton'), (14201, 14280, 'Buffalo'), 
    (14602, 14694, 'Rochester')
]

def input_county_zip(zip_code):
    try:
        zip_code = int(zip_code)  
    except ValueError:  
        return 'Unknown'
        
    matched_labels = [label for lower, upper, label in zips if lower <= zip_code <= upper]
    return matched_labels[0] if matched_labels else 'Other'
    